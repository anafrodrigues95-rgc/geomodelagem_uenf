# açai > 2026-07-02 1:46pm
https://universe.roboflow.com/anas-workspace-5npb9/acai-v4l4k

Provided by a Roboflow user
License: CC BY 4.0

